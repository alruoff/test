public class Main {
    public static void main(String[] args) {
        /*Задание 2.
        Напишите программу, которая выводит на экран сумму двух чисел 54 + 16
        */
        System.out.print("Сумма двух чисел 54 и 16 равна ");System.out.println(54+16);

    }
}