public class Main {
    public static void main(String[] args) {
        /*First level: Задание 1.
        В методе main инициализировать все целочисленные примитивные типы и
        вывести их в консоль в примерном виде "Переменная с типом
        <Здесь вы выводите название типа переменной> и названием <Здесь вы выводите название
        вашей переменной> имеет значение равное <Здесь вы выводите значение вашей переменной>"
        */
        byte etwasByte=11;
        short etwasShort=22;
        int etwasInt=33;
        long etwasLong=444L;

        System.out.print("Переменная с типом byte и названием etwasByte имеет значение равное ");System.out.println(etwasByte);
        System.out.print("Переменная с типом short и названием etwasShort имеет значение равное ");System.out.println(etwasShort);
        System.out.print("Переменная с типом int и названием etwasInt имеет значение равное ");System.out.println(etwasInt);
        System.out.print("Переменная с типом long и названием etwasLong имеет значение равное ");System.out.println(etwasLong);

    }
}