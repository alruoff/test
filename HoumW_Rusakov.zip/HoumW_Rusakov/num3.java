public class Main {
    public static void main(String[] args) {
        /*
        Задание 3.Напишите программу, которая выводит на экран результат деления двух чисел. 50/3
        */
        System.out.print("Частное от деления 50 на 3 равно ");System.out.println(50.0/3.0);

    }
}