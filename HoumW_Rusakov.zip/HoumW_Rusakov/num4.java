public class Main {
    public static void main(String[] args) {
        /*
        Задание 4.
        Напишите программу, которая выводит на экран значение переменной
        типа int  в квадрате (n* n).
        Предварительно объявите эту переменную и задайте ее значение.
        */
        int n=34;

        System.out.print("Возведение N в квадрат.Если N=34 : NxN=");System.out.println(n*n);

    }
}